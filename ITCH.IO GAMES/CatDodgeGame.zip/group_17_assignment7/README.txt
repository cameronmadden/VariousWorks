To run the code:
	- ensure that the data folder is filled with the necessary images and font
	- open the 'group_17_assignment7.pde' file and click 'Run' to display the animation
	- The game is controlled using either WASD or the arrow keys. 'p' is used to pause the game. Mouse press is used to restart the game. 