//
//  PagePhotoCell.swift
//  exploreAustin
//
//  Created by Matthew Plaisance on 11/18/22.
//

import UIKit

class PagePhotoCell: UICollectionViewCell {
    
    
    @IBOutlet weak var pageImageView: UIImageView!
    
    
}
