To run the code:
	- ensure that the data folder is filled with the necessary images
	- open the 'group_17_assignment6.pde' file and click 'Run' to display the animation